package com.yoho.ind;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button Login,complaint;
    private TextView Newuser;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Get the view from activity_main.xml
        setContentView(R.layout.activity_main);

        // Locate the button in activity_main.xml
        Login= (Button) findViewById(R.id.btn_login);
        complaint= (Button) findViewById(R.id.btn_complaint);
        Newuser= (TextView) findViewById(R.id.txt_newuser);


        // Capture button clicks
        Login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(MainActivity.this,
                        LoginPage.class);
                startActivity(myIntent);

            }
        });
        complaint.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(MainActivity.this,
                        ComplaintPage.class);
                startActivity(myIntent);

            }
        });

        // Capture button clicks
        Newuser.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity.class
                Intent myIntent = new Intent(MainActivity.this,
                        NewUser_Activity.class);
                startActivity(myIntent);

            }
        });
    }

}